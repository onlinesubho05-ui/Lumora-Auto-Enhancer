# LUMORA AUTO ENHANCER — Code on the Go build

## What this prototype does

Normal phone Camera
→ Camera saves the original photo to Gallery
→ Lumora detects a new image
→ Lumora enhances it
→ Lumora saves a processed copy to Pictures/Lumora

This is a proof-of-concept. The original is NOT deleted.

## Important limitation

Android normally does not let a third-party app intercept another camera app's capture pipeline before the camera writes its photo. This project therefore watches MediaStore after the camera has saved the photo.

Photo only in V0.1. Video will be added after the photo pipeline is reliable.

## Code on the Go

Use the current Code on the Go release. Current releases use a newer Android toolchain, so this project targets the current stack.

The project intentionally has no GitHub dependency and no server.

## Import / build

1. Install Code on the Go on Android.
2. Download/extract this ZIP.
3. In CoGo choose Open/Import existing project.
4. Select the folder containing `settings.gradle.kts`.
5. Let the project sync.
6. Build the debug APK.
7. Install the APK.
8. Open Lumora Auto Enhancer.
9. Allow photo access and notification permission when requested.
10. Tap Enable Auto Enhance.
11. Open the phone's normal Camera app.
12. Take ONE test photo.
13. Wait several seconds.
14. Open Gallery → Pictures → Lumora.

## If the build fails

The most likely cause is a toolchain/SDK mismatch. CoGo is evolving quickly. Use a newly created simple Kotlin Android project in the current CoGo version first. If that builds, then import this project.

## Next versions

- Process multiple new photos instead of only the newest one.
- Wait for MediaStore `IS_PENDING = 0`.
- Add a processing queue.
- Add better camera-aware enhancement.
- Add video processing.
- Add a setting for enhancement strength.
- Only consider original deletion after extensive testing.
