package com.lumora.autoenhancer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.lumora.autoenhancer.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            updateUi()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.accessButton.setOnClickListener { requestPermissionsNow() }
        binding.toggleButton.setOnClickListener { toggleWatcher() }
        updateUi()
    }

    private fun requestPermissionsNow() {
        val permissions = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= 33) {
            permissions += Manifest.permission.READ_MEDIA_IMAGES
            permissions += Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            permissions += Manifest.permission.POST_NOTIFICATIONS
        } else {
            permissions += Manifest.permission.READ_EXTERNAL_STORAGE
        }

        permissionLauncher.launch(permissions.toTypedArray())
    }

    private fun hasImageAccess(): Boolean {
        return if (Build.VERSION.SDK_INT >= 33) {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_MEDIA_IMAGES
            ) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun toggleWatcher() {
        if (!hasImageAccess()) {
            requestPermissionsNow()
            return
        }

        val enabled = !getPreferences(MODE_PRIVATE).getBoolean("enabled", false)
        getPreferences(MODE_PRIVATE).edit().putBoolean("enabled", enabled).apply()

        val intent = Intent(this, MediaWatchService::class.java)
        if (enabled) {
            ContextCompat.startForegroundService(this, intent)
        } else {
            stopService(intent)
        }
        updateUi()
    }

    private fun updateUi() {
        val enabled = getPreferences(MODE_PRIVATE).getBoolean("enabled", false)
        binding.statusText.text =
            if (enabled) "Status: ON\nWaiting for a new camera photo…"
            else "Status: OFF"
        binding.toggleButton.text =
            if (enabled) "Disable Auto Enhance" else "Enable Auto Enhance"
    }
}
