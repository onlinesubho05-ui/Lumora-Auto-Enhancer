package com.lumora.autoenhancer

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min

object LumoraEngine {

    fun enhance(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val out = src.copy(Bitmap.Config.ARGB_8888, true)

        // Fast global exposure estimate from a sparse luminance sample.
        var sum = 0.0
        var count = 0
        val stepX = max(1, w / 32)
        val stepY = max(1, h / 32)

        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val c = src.getPixel(x, y)
                val lum = 0.2126 * Color.red(c) +
                        0.7152 * Color.green(c) +
                        0.0722 * Color.blue(c)
                sum += lum
                count++
                x += stepX
            }
            y += stepY
        }

        val avg = if (count == 0) 128.0 else sum / count
        val exposure = when {
            avg < 78 -> 1.18
            avg < 105 -> 1.08
            avg > 190 -> 0.91
            avg > 165 -> 0.96
            else -> 1.0
        }

        val pixels = IntArray(w * h)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        for (i in pixels.indices) {
            val c = pixels[i]
            var r = Color.red(c) * exposure
            var g = Color.green(c) * exposure
            var b = Color.blue(c) * exposure

            // Shadow lift + highlight protection.
            r = tone(r)
            g = tone(g)
            b = tone(b)

            // Very mild color refinement.
            val l = (r * 0.2126 + g * 0.7152 + b * 0.0722)
            val sat = if (l < 55) 1.04 else 1.025
            r = l + (r - l) * sat
            g = l + (g - l) * sat
            b = l + (b - l) * sat

            // Tiny warm bias to avoid a cold phone-camera look.
            r *= 1.006
            b *= 0.997

            pixels[i] = Color.rgb(
                r.toInt().coerceIn(0, 255),
                g.toInt().coerceIn(0, 255),
                b.toInt().coerceIn(0, 255)
            )
        }

        out.setPixels(pixels, 0, w, 0, 0, w, h)
        return out
    }

    private fun tone(v0: Double): Double {
        var v = v0
        v += when {
            v < 70 -> (70 - v) * 0.16
            v > 215 -> -(v - 215) * 0.18
            else -> 0.0
        }
        val n = (v / 255.0).coerceIn(0.0, 1.0)
        val curved = if (n < 0.5) 0.5 * (2 * n).pow(1.04)
        else 1.0 - 0.5 * (2 * (1.0 - n)).pow(1.02)
        return curved * 255.0
    }

    private fun Double.pow(p: Double): Double =
        kotlin.math.exp(kotlin.math.ln(this.coerceAtLeast(1e-9)) * p)
}
