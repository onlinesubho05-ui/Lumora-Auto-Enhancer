package com.lumora.autoenhancer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentUris
import android.content.Intent
import android.database.ContentObserver
import android.database.Cursor
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.IOException

class MediaWatchService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var observer: ContentObserver? = null
    private var processing = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, notification("Watching for new camera photos"))
        registerObserver()
    }

    private fun registerObserver() {
        val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                super.onChange(selfChange, uri)
                scheduleCheck()
            }
        }
        observer = obs
        contentResolver.registerContentObserver(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            true,
            obs
        )
    }

    private fun scheduleCheck() {
        if (processing) return
        processing = true
        scope.launch {
            try {
                delay(1200)
                processNewestImage()
            } finally {
                processing = false
            }
        }
    }

    private fun processNewestImage() {
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.RELATIVE_PATH,
            MediaStore.Images.Media.IS_PENDING
        )

        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(
                collection,
                projection,
                null,
                null,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )

            if (cursor == null || !cursor.moveToFirst()) return

            val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
            val name = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME))
            val relativePath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.RELATIVE_PATH)) ?: ""
            val pending = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.IS_PENDING))

            if (pending != 0) return
            if (relativePath.contains("Pictures/Lumora", ignoreCase = true)) return
            if (name.startsWith("lumora_", ignoreCase = true)) return

            val lastProcessed = getSharedPreferences("state", MODE_PRIVATE)
                .getLong("last_id", -1L)

            if (id <= lastProcessed) return

            val uri = ContentUris.withAppendedId(collection, id)
            enhanceAndSave(uri)
            getSharedPreferences("state", MODE_PRIVATE).edit()
                .putLong("last_id", id)
                .apply()

        } finally {
            cursor?.close()
        }
    }

    private fun enhanceAndSave(sourceUri: Uri) {
        updateNotification("Enhancing new photo…")

        val original = contentResolver.openInputStream(sourceUri)?.use {
            BitmapFactory.decodeStream(it)
        } ?: throw IOException("Could not decode source image")

        val enhanced = LumoraEngine.enhance(original)

        MediaStoreWriter.saveJpeg(
            context = this,
            bitmap = enhanced,
            displayName = "lumora_${System.currentTimeMillis()}.jpg"
        )

        original.recycle()
        if (enhanced !== original) enhanced.recycle()

        updateNotification("Saved enhanced photo to Pictures/Lumora")
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, notification(text))
    }

    private fun notification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Lumora Auto Enhancer")
            .setContentText(text)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "Lumora Auto Enhancer",
                NotificationManager.IMPORTANCE_LOW
            )
        )
    }

    override fun onDestroy() {
        observer?.let { contentResolver.unregisterContentObserver(it) }
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "lumora_auto_enhancer"
        private const val NOTIFICATION_ID = 4101
    }
}
